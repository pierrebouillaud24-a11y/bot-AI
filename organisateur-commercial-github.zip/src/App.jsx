
import React,{useState} from 'react';
export default function App(){
 const [tasks,setTasks]=useState([{id:1,title:'Préparer offre',category:'Offres',done:false}]);
 const done=tasks.filter(t=>t.done).length;
 return <div style={{fontFamily:'Arial',padding:20}}>
 <h1>Organisateur Commercial</h1>
 <p>Progression: {Math.round(done/tasks.length*100||0)}%</p>
 <button onClick={()=>setTasks([...tasks,{id:Date.now(),title:'Nouvelle tâche',category:'Travail',done:false}])}>Ajouter</button>
 <button onClick={()=>alert('Teams')}>Teams</button>
 <button onClick={()=>alert('Outlook')}>Outlook</button>
 <h2>Tableau de bord</h2>
 <ul>{tasks.map(t=><li key={t.id}><input type='checkbox' checked={t.done} onChange={()=>setTasks(tasks.map(x=>x.id===t.id?{...x,done:!x.done}:x))}/> {t.title} ({t.category})</li>)}</ul>
 <h3>Fonctionnalités prévues</h3><p>Calendrier, vue hebdomadaire, rappels email, statistiques.</p>
 </div>
}
